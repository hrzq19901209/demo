def main():
    print 'I love you'